package com.example.demo.control;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.mapper.UserMapper;
import com.example.demo.pojo.User;


//通过注解操作数据库
@Controller
public class UserControl {
	
	private List<User> list;
	
	@Autowired
	UserMapper userMapper;

	@RequestMapping("/add")
	public String welcome() {
		/*userMapper.insert(new User(1,"aa", 12));
		userMapper.insert(new User(2,"bb", 13));
		userMapper.insert(new User(3,"cc", 34));*/
		
		userMapper.insert(new User("aa", 12));
		userMapper.insert(new User("bb", 13));
		userMapper.insert(new User("cc", 34));
		
		return "index";
	}
	
	@RequestMapping("/getusers")
	public String getusers(Model model) {
		list=userMapper.getAll();
		System.out.println(list.toString());
		model.addAttribute("userlist", list);
		
		return "index";
	}
	
	@RequestMapping("/del/{id}")
	public String del(@PathVariable Integer id) {
		userMapper.delete(id);
		
		return "index";
	}
	
	@RequestMapping("/del/{id}/{name}")
	public String update(@PathVariable Integer id,@PathVariable String name) {
		User user=userMapper.getOne(id);
		user.setName(name);
		userMapper.update(user);
		
		return "index";
	}
}
