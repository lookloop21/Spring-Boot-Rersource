package com.example.demo.control;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.pojo.User;
import com.example.demo.services.UserServices;

//通过xml文件配置操作数据库
@Controller
public class UserXmlControl {
	
	private List<User> list;
	
	@Autowired
	UserServices services;

	@RequestMapping("/addXml")
	public String welcome() {
		/*services.insert(new User(1,"aa", 12));
		services.insert(new User(2,"bb", 13));
		services.insert(new User(3,"cc", 34));*/
		
		services.insert(new User("aa", 12));
		services.insert(new User("bb", 13));
		services.insert(new User("cc", 34));
		
		return "index";
	}
	
	@RequestMapping("/getusersXml")
	public String getusers(Model model) {
		list=services.getAll();
		System.out.println(list.toString());
		model.addAttribute("userlist", list);
		
		return "index";
	}
	
	@RequestMapping("/delXml/{id}")
	public String del(@PathVariable Integer id) {
		services.delete(id);
		
		return "index";
	}
	
	@RequestMapping("/delXml/{id}/{name}")
	public String update(@PathVariable Integer id,@PathVariable String name) {
		User user=services.getOne(id);
		user.setName(name);
		services.update(user);
		
		return "index";
	}
}
