package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.UserDao;
import com.example.demo.pojo.User;

@Service
public class UserServices {
	
	@Autowired
	UserDao dao;
	
	public List<User> getAll(){
		return dao.getAll();
	}
	
	public User getOne(Integer id) {
		return dao.getOne(id);
	}
	
	public void insert(User user) {
		dao.insert(user);
	}
	
	public void delete(Integer id) {
		dao.delete(id);
	}
	
	public void update(User user) {
		dao.update(user);
	}

}
