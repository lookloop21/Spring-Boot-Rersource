package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.type.JdbcType;

import com.example.demo.pojo.User;

@Mapper
public interface UserMapper {

	@Select("select * from users")
    @Results({
        @Result(property = "id",  column = "id", jdbcType=JdbcType.INTEGER),
        @Result(property = "name",  column = "name", jdbcType=JdbcType.VARCHAR),
        @Result(property = "age",  column = "age", jdbcType=JdbcType.INTEGER)
    })
	List<User> getAll();
	
	
	@Select("select * from users where id=#{id}")
    @Results({
        @Result(property = "id",  column = "id", jdbcType=JdbcType.INTEGER),
        @Result(property = "name",  column = "name", jdbcType=JdbcType.VARCHAR),
        @Result(property = "age",  column = "age", jdbcType=JdbcType.INTEGER)
    })
	User getOne(Integer id);
	
	
	//@Insert("INSERT INTO users(id,name,age) VALUES(#{id},#{name}, #{age})")
	@Insert("INSERT INTO users(name,age) VALUES(#{name}, #{age})")
	void insert(User user);
	
	@Update("update users set name=#{name},age=#{age} where id=#{id}")
	void update(User user);
	
	@Delete("delete from users where id=#{id}")
	void delete(Integer id);
}
