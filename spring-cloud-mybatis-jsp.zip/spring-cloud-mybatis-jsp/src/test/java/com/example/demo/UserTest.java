package com.example.demo;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.mapper.UserMapper;
import com.example.demo.pojo.User;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserTest {

	@Autowired
	UserMapper userMapper;
	
	@Test
	public void insert() {
		userMapper.insert(new User("aa", 12));
		userMapper.insert(new User("bb", 13));
		userMapper.insert(new User("cc", 34));

		Assert.assertEquals(3, userMapper.getAll().size());
	}
}
