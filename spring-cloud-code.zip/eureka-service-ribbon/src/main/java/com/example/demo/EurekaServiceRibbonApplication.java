package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@EnableDiscoveryClient //向服务中心注册(用于消费)
@EnableEurekaClient
@SpringBootApplication
@EnableHystrix		   //开启断路功能
public class EurekaServiceRibbonApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaServiceRibbonApplication.class, args);
	}

	@Bean			//声明一个Bean
	@LoadBalanced	//设置负载均衡的功能
	RestTemplate restTemplate() {
		return new RestTemplate();
	}
}

