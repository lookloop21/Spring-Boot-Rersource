package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@EnableEurekaClient 	//eureka客户端声明
@SpringBootApplication
@RestController			//页面返回内容
public class EurekaClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaClientApplication.class, args);
	}
	
	@Value("${server.port}")	//得到服务端端口 8762
	String port;
	@RequestMapping("/hi")		//访问路径
	public String home(@RequestParam String name) {
		return "hi "+name+",i am from port:" +port;
	}

}

